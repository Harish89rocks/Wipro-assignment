package com.projects;

public class command2 {

		public static void main(String[] args) {
			
			String a = args[0];
			String b = args[1];
			String c = a+"\t" + "Technologies"+"\t"+b;
			
			System.out.println("The command line :"+c);

		}

}
