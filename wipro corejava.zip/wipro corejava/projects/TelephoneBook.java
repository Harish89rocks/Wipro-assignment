package com.projects;
	import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

	public class TelephoneBook {
		static Map<String, String> tel_dir_map= new HashMap<String, String>();     	
	        public static void main(String[] args) {
	        	
	        	 Map<String, Integer> tel_dir_map = new HashMap<String, Integer>();
	        	 
                 tel_dir_map.put("Mike", 1456789100);

                 tel_dir_map.put("Nina", 1424541000);

                 tel_dir_map.put("Danial", 1456789770);

                 tel_dir_map.put("Usman", 1421712314);
	        
		
	        	  System.out.println("Enter Name (Mike, Nina, Danial, Usman): ");
	        	  
                  Scanner scanner = new Scanner(System.in);

                  String Str_name = scanner.nextLine();

        System.out.println("The Number of " + Str_name + ": " + tel_dir_map.get(Str_name));
	        }
 	        	
}
