package com.projects;

public class exception1 {

		public static void main(String[] args) throws InvalidAgeException {
			
		
				 
			String name = args[0];
			
			int age = Integer.parseInt(args[1]);
			
			if (age < 18 || age >= 60)
				throw new InvalidAgeException("CoustomMessage: "+"invalid age");
			
			System.out.println("Name: " + name + " Age: " + age);

	
		}
}
 class InvalidAgeException extends Exception {
	
	public InvalidAgeException(String string) 
    { 
        // Call constructor of parent Exception 
        super(string); 
       
        
    } 
}
