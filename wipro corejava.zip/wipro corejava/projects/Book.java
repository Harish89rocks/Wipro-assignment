package com.projects;

public class Book {

	String title;
	String author;
	double price;
	int isbn;

	// constructor
	Book(String title, String author, double newPrice, int isbn) {
		this.title = title;
		this.author = author;
		this.price = newPrice;
		this.isbn = isbn;
		displayDetails();

	}

	public void displayDetails() {
		System.out.println("book details\n" + "title:" + title + "\n" + "author: " + author + "\n" + "price:" + price
				+ "\n" + "isbn: " + isbn);

	}

	public void discountedprice(double markedprice) {
		double dis, amount, s;

		// markedprice=1000;

		dis = 25; // 25 mean 25%

//	             
		s = 100 - dis;

		amount = (s * markedprice) / 100;

		System.out.println("amount after\t" + dis + "\t" + "discount=" + amount);

	}

	public static void main(String[] args) {
		Book obj = new Book("core", "herry", 1000.5, 101);
		obj.discountedprice(1000);

		// System.out.println(""+obj.getPrice());
	}
}
