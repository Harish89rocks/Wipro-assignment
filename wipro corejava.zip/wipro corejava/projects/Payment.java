package com.projects;

public abstract class Payment {

		protected double cash;
		Payment(double val) 
		{
				this.cash = Math.round(val*100)/100.0;
			}
		public double getcash() 
		{
				return cash;
			}
		public void setcash(double newval) 
		{
				this.cash = newval;
			}
		public void paymentDetails() 
		{
				System.out.println("The payment of cash: Rupee" +this.cash);
			}
		public static void main(String[] args) 
		{
		CreditCardPayment x = new CreditCardPayment(2.12, "Modhi","11/27", "************1234");

				CashPayment p = new CashPayment(20.03);

		CreditCardPayment y = new CreditCardPayment(11.22, "Herry","22/11","987654321");

				CashPayment q = new CashPayment(55.12);
				
				x.paymentDetails();
				p.paymentDetails();
				y.paymentDetails();
				q.paymentDetails();
			}
}

class CashPayment extends Payment
{

	CashPayment(double val) 
	{
		super(val);
	}

	public void paymentDetails()
	{
		System.out.println("The payment of cash:  Rupee" + this.cash);
	}
}

class CreditCardPayment extends Payment 
{

	public String name, expDate, number;

	CreditCardPayment(double value, String name, String expDate, String number) 
	{
		super(value);
		this.number = number;
		this.expDate = expDate;
		this.name = name;
	}

	public void paymentDetails() {
	System.out.println("The payment of Rupee" + this.cash + " through the card " + this.number
        + ",  and expire date "	+ this.expDate + ", and the owner name: " + this.name + ".");
	}

}
class TestDemo
{
	
	
	
}
