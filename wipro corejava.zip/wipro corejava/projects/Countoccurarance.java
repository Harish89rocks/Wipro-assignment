package com.projects;

import java.util.HashMap;
import java.util.Scanner;

public class Countoccurarance {

	private static void characterCount (String inputString){
		
		HashMap<Character, Integer> charcountMap = new HashMap<Character, Integer>();
		
		char[] strArray = inputString.toCharArray();
		
		for (char c : strArray)
		{
			if(charcountMap.containsKey(c))
			{
			charcountMap.put(c, charcountMap.get(c)+1);
			}
			else
			{
				charcountMap.put(c, 1);
			}
		}
		System.out.println(inputString+":"+charcountMap);
	}
	public static void main(String[] args)
	{
		characterCount("Java J2EE Java JSP J2EE");
		characterCount("All is well");
		
		//Scanner sc= new Scanner(System.in);
		//System.out.println("Enter input");
		//String nextLine = sc.nextLine();
		//characterCount(nextLine);
		
	}
	
}

