package wipro.org;

	import java.net.MalformedURLException;
	import java.net.URL;
	 
	import org.openqa.selenium.By;
	import org.openqa.selenium.Platform;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.firefox.FirefoxDriver;
	import org.openqa.selenium.remote.DesiredCapabilities;
	import org.openqa.selenium.remote.RemoteWebDriver;
	import org.testng.annotations.DataProvider;
	import org.testng.annotations.Test;
	 
	public class SeleniumParallel extends BaseClass {
	 
	    @Test
	    public void test_01() throws InterruptedException, MalformedURLException{
	        try{
	            getDriver().get("https://demo.opencart.com/");
	 
	            getDriver().findElement(By.xpath("//span[text()='My Account']")).click();
	 
	            getDriver().findElement(By.linkText("Login")).click();
	            
	            
	            Thread.sleep(10000);
	 
	            getDriver().findElement(By.name("email")).sendKeys("Harish1989bangalore@gmail.com");
	            Thread.sleep(5000);
	 
	        }
	        catch(Exception e){
	            System.out.println(e);
	        }
	    }
	}
