package wipro.org;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Test1 {
	
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver dr = new ChromeDriver();
		
		dr.get("https://demo.opencart.com/");
		
		dr.manage().window().maximize();
		
		dr.findElement(By.xpath("//span[text()='My Account']")).click();
		
		dr.findElement(By.linkText("Login")).click();
		
		dr.findElement(By.name("email")).sendKeys("Harish1989bangalore@gmail.com");
		
		dr.findElement(By.id("input-password")).sendKeys("Wipro@123");
		
		dr.findElement(By.xpath("//input[@type='submit']")).click();
		
		dr.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		
		dr.findElement(By.xpath("//input[@placeholder='Search']")).sendKeys("Component");
		
		dr.findElement(By.xpath("//button[@class='btn btn-default btn-lg']")).click();
		dr.findElement(By.xpath("//button[@class='btn btn-default btn-lg']")).click();
		Select dropdown = new Select(dr.findElement(By.name("category_id")));
		dropdown.selectByValue("28");
		dropdown.selectByValue("35");
		
		/*
		 * WebElement chkbox = dr.findElement(By.name("sub_category"));
		 * 
		 * for (int i = 0; i < 1; i++) { chkbox.click();
		 * 
		 * }
		 * 
		 * dr.findElement(By.xpath("//input[@id='button-search']")).click();
		 */
		dr.findElement(By.xpath("//a[contains(text(),'Phones & PDAs')]")).click();
        
        Select dropdown1 = new Select(dr.findElement(By.id("input-sort")));
        dropdown1.selectByValue("https://demo.opencart.com/index.php?route=product/category&path=24&sort=p.price&order=DESC");
       
        dr.findElement(By.xpath("//div[@id='content']//div[1]//div[1]//div[2]//div[2]//button[3]")).click();
        
        dr.findElement(By.xpath("//body//div[@class='row']//div[@class='row']//div[2]//div[1]//div[2]//div[2]//button[3]")).click();
        
        dr.findElement(By.xpath("//a[@id='compare-total']")).click();
        
        dr.findElement(By.xpath("//td[2]//input[1]")).click();
        
        //dr.findElement(By.xpath("//a[contains(text(),'shopping cart')]")).click();
        
       // dr.get("https://demo.opencart.com/index.php?route=checkout/cart/");
      

        
       
        dr.navigate().to("https://demo.opencart.com/index.php?route=checkout/cart");   
        dr.findElement(By.linkText("shopping cart")).click();
        
       // dr.findElement(By.xpath("//a[@class='btn btn-primary']")).click();
        	
	}

}
